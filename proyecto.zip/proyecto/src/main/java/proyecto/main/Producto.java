package proyecto.main;

public class Producto {

	private String idProducto; 
	private String nombreProducto;
	private int precio;
	private int cantidadIngresada;
	private int cambio;
	
	public String getIdProducto() {
		return idProducto;
	}
	public void setIdProducto(String idProducto) {
		this.idProducto = idProducto;
	}
	public String getNombreProducto() {
		return nombreProducto;
	}
	public void setNombreProducto(String nombreProducto) {
		switch (nombreProducto) {
		case "A":
			this.nombreProducto = "Papas";
			break;
		case "B":
			this.nombreProducto = "Refresco";
			break;
		case "C":
			this.nombreProducto = "Chocolate";
		default:
			break;
		}
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	public int getCantidadIngresada() {
		return cantidadIngresada;
	}
	public void setCantidadIngresada(int cantidadIngresada) {
		this.cantidadIngresada = cantidadIngresada;
	}
	public int getCambio() {
		return cambio;
	}
	public void setCambio(int cambio) {
		this.cambio = cambio;
	}
	
	
}
