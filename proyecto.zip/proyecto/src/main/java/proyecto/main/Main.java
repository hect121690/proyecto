package proyecto.main;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
	
	private static Scanner sn = new Scanner(System.in);
	private static int[] MONEDAS = { 10, 50, 100 };
	private static int PRECIO_PRODUCTO_A = 270;
	private static int PRECIO_PRODUCTO_B = 340;
	private static int PRECIO_PRODUCTO_C = 390;
	
	public static void main(String[] args) {
		
		List<Cliente> clientes = new ArrayList<Cliente>();
		
		boolean nuevo = true;
		String respuesta = null;
		
		while (nuevo) {
			Cliente clienteMaquina = maquinaProductos();
			clientes.add(clienteMaquina);

			System.out.println("Cliente Nuevo? \n Escriba SI o NO");
			respuesta = sn.next();

			if (respuesta.equals("SI") || respuesta.equals("si") || respuesta.equals("Si")) {
				nuevo = true;
			} else if (respuesta.equals("NO") || respuesta.equals("no") || respuesta.equals("No")) {
				nuevo = false;
			}
		}
		
		for (Cliente cliente : clientes) {
			System.out.println("El cliente : " + cliente.getNombreCliente().toUpperCase().charAt(0) + cliente.getNombreCliente().substring(1, cliente.getNombreCliente().length()).toLowerCase() 
								+" compro "  + cliente.getProductos().size() + " productos");			
			for (Producto producto : cliente.getProductos()) {
				System.out.println("Producto : " + producto.getIdProducto() + " | " + producto.getNombreProducto());
				System.out.println("Precio : " + producto.getPrecio());
				System.out.println("Pagado : "+ producto.getCantidadIngresada());
				System.out.println("Cambio : " + producto.getCambio());		
			}
		}
	}
	
	public static Cliente maquinaProductos() {
		String nombre;
		int cantidad = 0, precio = 0, moneda = 0;

		Cliente cliente = new Cliente();
		cliente.setProductos(new ArrayList<Producto>());
		List<Producto> productos = new ArrayList<Producto>();

		String productoElegido;
		boolean salir = false;

		System.out.print("Ingrese su Nombre por favor: ");
		nombre = sn.next();

		cliente.setNombreCliente(nombre);
		System.out.println("Hola " + nombre.toUpperCase().charAt(0) + nombre.substring(1, nombre.length()).toLowerCase() + " elije un productor por favor.");

		while (!salir) {

			System.out.println("*************************** ");
			System.out.println("*  PRODUCTO   *  PRECIO   * ");
			System.out.println("*************************** ");
			System.out.println("*  Producto A * $ 270.00  * ");
			System.out.println("*  Producto B * $ 340.00  * ");
			System.out.println("*  Producto C * $ 100.00  * ");
			System.out.println("*                         * ");
			System.out.println("Si desea Terminar escriba Salir");
			System.out.println("*************************** ");
			

			try {

				System.out.println("Elija un producto: ");
				productoElegido = sn.next().toUpperCase();

				switch (productoElegido) {
				case "A":
					precio = PRECIO_PRODUCTO_A;
					productos.add(ingreseMonedas(cantidad, precio, moneda, productoElegido));
					break;
				case "B":
					precio = PRECIO_PRODUCTO_B;
					productos.add(ingreseMonedas(cantidad, precio, moneda, productoElegido));
					break;
				case "C":
					precio = PRECIO_PRODUCTO_C;
					productos.add(ingreseMonedas(cantidad, precio, moneda, productoElegido));
					break;
				case "Salir": case "salir": case "SALIR":
					salir = true;
					break;
				default:
					System.out.println("Solo puede elegir un producto de la lista o salir.");
				}
			} catch (InputMismatchException e) {
				System.out.println("Debes insertar un caracter");
				sn.next();
			}
		}		
		cliente.setProductos(productos);
		return cliente;
	}
	
	public static Producto ingreseMonedas(int cantidad, int precio, int moneda, String productoElegido) {
		int cambio = 0;
		Producto producto = new Producto();
		producto.setIdProducto(productoElegido);
		producto.setNombreProducto(productoElegido);

		while (cantidad < precio) {
			System.out.println("Ingrese Monedas :");
			moneda = sn.nextInt();
			boolean validaMoneda = false;
			for (int i = 0; i < MONEDAS.length; i++) {
				if (MONEDAS[i] == moneda) {
					validaMoneda = true;
					break;
				}
			}
			if (!validaMoneda) {
				System.out.println("Solo se permiten las siguientes monedas : 10, 50, 100 ");
			} else {
				cantidad = cantidad + moneda;
			}
		}
		if (cantidad >= precio) {
			cambio = cantidad - precio;
			System.out.println("La cantidad ingresada fue : " + cantidad);
			System.out.println("El costo del producto es : " + precio);			
			cambioDevuelto(cambio);
			producto.setPrecio(precio);
			producto.setCambio(cambio);
			producto.setCantidadIngresada(cantidad);
			
		}
		return producto;
	}

	private static void cambioDevuelto(int cambio) {
		List<Integer> listCambio = new ArrayList<>();

		while (cambio >= MONEDAS[2]) {
			cambio = cambio - MONEDAS[2];
			listCambio.add(MONEDAS[2]);
		}
		while (cambio >= MONEDAS[1]) {
			cambio = cambio - MONEDAS[1];
			listCambio.add(MONEDAS[1]);
		}
		while (cambio >= MONEDAS[0]) {
			cambio = cambio - MONEDAS[0];
			listCambio.add(MONEDAS[0]);
		}
		
		System.out.println("Su cambio es : ");
		for (int c : listCambio) {
			System.out.println(c);
		}
	}

}
